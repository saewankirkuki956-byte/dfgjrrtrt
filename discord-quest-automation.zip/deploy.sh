#!/bin/bash
# ============================================================
# ALL IN ONE — Discord Quest Automation
# VPS Deployment Script (Run manually on your Hovix Cloud VPS)
# ============================================================

set -e

# ===== Configuration =====
APP_NAME="ALL IN ONE"
APP_DIR="/var/www/all-in-one"
DOMAIN="all-in-one.local"  # Change to your actual domain
NODE_PORT=3000
USERNAME=$(whoami)

echo "========================================"
echo "  $APP_NAME — Deployment Script"
echo "  Server: $(hostname)"
echo "  Target: $APP_DIR"
echo "  User: $USERNAME"
echo "========================================"

# ===== 1. System Update & Dependencies =====
echo "[1/8] Updating system packages..."
sudo apt-get update -qq
sudo apt-get upgrade -y -qq

echo "  Installing Node.js LTS..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
    sudo apt-get install -y nodejs
fi
echo "  Node.js: $(node --version)"
echo "  npm: $(npm --version)"

echo "  Installing Nginx..."
sudo apt-get install -y nginx

echo "  Installing Certbot..."
sudo apt-get install -y certbot python3-certbot-nginx

echo "  Installing PM2..."
sudo npm install pm2 -g

# ===== 2. Create Project Directory =====
echo "[2/8] Setting up project directory..."
sudo mkdir -p "$APP_DIR"
sudo chown -R $USERNAME:$USERNAME "$APP_DIR"

# ===== 3. Copy Project Files =====
echo "[3/8] Copying project files..."
if [ -d "/tmp/discord-quest-automation" ]; then
    cp -r /tmp/discord-quest-automation/* "$APP_DIR/"
    echo "  Project files copied from /tmp/discord-quest-automation"
elif [ -d "$HOME/discord-quest-automation" ]; then
    cp -r "$HOME/discord-quest-automation/"* "$APP_DIR/"
    echo "  Project files copied from $HOME/discord-quest-automation"
else
    echo "  WARNING: Project files not found in common locations."
    echo "  Please upload the project to $APP_DIR manually before continuing."
    echo "  To upload via SCP:"
    echo "    scp -r ./discord-quest-automation/* $USERNAME@$(hostname):$APP_DIR/"
    echo "  Then re-run this script."
fi

if [ -f "$APP_DIR/package.json" ]; then
    echo "  Installing npm dependencies..."
    cd "$APP_DIR"
    npm install
else
    echo "  ERROR: package.json not found in $APP_DIR"
    exit 1
fi

# ===== 4. PM2 Process Setup =====
echo "[4/8] Configuring PM2..."
pm2 stop all-in-one 2>/dev/null || true
pm2 delete all-in-one 2>/dev/null || true

cd "$APP_DIR"
pm2 start server.js --name "all-in-one" \
    --log-date-format "YYYY-MM-DD HH:mm:ss" \
    --watch false \
    --max-restarts 5 \
    --min-uptime 3000s
pm2 save
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USERNAME --hp $HOME
sudo systemctl enable pm2-$USERNAME || true
echo "  PM2 process started."

# ===== 5. Nginx Reverse Proxy =====
echo "[5/8] Configuring Nginx reverse proxy..."
sudo tee /etc/nginx/sites-available/all-in-one > /dev/null << 'NGINX_CONF'
server {
    listen 80;
    server_name __DOMAIN__;

    client_max_body_size 10M;

    location / {
        proxy_pass http://127.0.0.1:__PORT__;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }
}
NGINX_CONF

sudo sed -i "s/__DOMAIN__/$DOMAIN/g" /etc/nginx/sites-available/all-in-one
sudo sed -i "s/__PORT__/$NODE_PORT/g" /etc/nginx/sites-available/all-in-one
sudo ln -sf /etc/nginx/sites-available/all-in-one /etc/nginx/sites-enabled/all-in-one
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
echo "  Nginx configured."

# ===== 6. Firewall =====
echo "[6/8] Configuring firewall..."
sudo ufw allow OpenSSH 2>/dev/null || true
sudo ufw allow 'Nginx Full' 2>/dev/null || true
sudo ufw --force enable 2>/dev/null || true

# ===== 7. Database Permissions =====
echo "[7/8] Setting up database permissions..."
if [ -f "$APP_DIR/tokens.db" ]; then
    sudo chown $USERNAME:$USERNAME "$APP_DIR/tokens.db"
    echo "  Database permissions set."
else
    echo "  No tokens.db found. Will be created on first run."
fi

# ===== 8. SSL Certificate =====
echo "[8/8] SSL Setup..."
echo "  To enable HTTPS, run: sudo certbot --nginx -d your-domain.com"
sudo systemctl restart nginx

echo ""
echo "========================================"
echo "  DEPLOYMENT COMPLETE!"
echo "========================================"
echo ""
echo "  Application: $APP_NAME"
echo "  Directory:   $APP_DIR"
echo "  Node Port:   $NODE_PORT"
echo "  Nginx Proxy: http://$DOMAIN"
echo "  PM2 Process: all-in-one"
echo ""
echo "  Commands:"
echo "    pm2 list"
echo "    pm2 logs all-in-one"
echo "    pm2 restart all-in-one"
echo "    sudo certbot --nginx -d your-domain.com"
echo ""
echo "  Dashboard: http://$DOMAIN"
echo ""
pm2 list

Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "C:\Users\hama\discord-quest-automation\node.exe C:\Users\hama\discord-quest-automation\server.js", 0, False

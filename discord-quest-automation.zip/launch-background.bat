@echo off
cd /d C:\Users\hama\discord-quest-automation
start /b node server.js
exit

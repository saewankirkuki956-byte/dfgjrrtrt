const axios = require('axios');

const TOKEN = 'MjQzNTY2OTgzMjIyNzg4MDk5.G_dxG2.YjGdpsSip17JQSOlCHAdQyCDw0_VVKuBJQee3g';
const JWT_SECRET = 'discord-quest-secret-key-change-in-production';
const jwt = require('jsonwebtoken');
const db = require('better-sqlite3')('./tokens.db');

const user = db.prepare('SELECT * FROM users WHERE username = ?').get('hama');
const authToken = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
const headers = { Authorization: `Bearer ${authToken}` };

(async () => {
    console.log('=== Userbot API Test ===\n');

    // 1. Check userbot status
    console.log('1. GET /api/userbot/status');
    const status = await axios.get('http://localhost:3000/api/userbot/status', { headers });
    console.log('   Status:', JSON.stringify(status.data, null, 2));

    // 2. Set custom prefix
    console.log('\n2. POST /api/userbot/prefix (set to "!")');
    const prefix = await axios.post('http://localhost:3000/api/userbot/prefix', { prefix: '!' }, { headers });
    console.log('   Result:', JSON.stringify(prefix.data));

    // 3. Check status again
    const status2 = await axios.get('http://localhost:3000/api/userbot/status', { headers });
    console.log('   Prefix after set:', status2.data.prefix);

    // 4. Start userbot
    console.log('\n4. POST /api/userbot/start');
    const start = await axios.post('http://localhost:3000/api/userbot/start', {}, { headers, timeout: 30000 });
    console.log('   Result:', JSON.stringify(start.data));

    // Wait for connection
    await new Promise(r => setTimeout(r, 5000));

    // 5. Check userbot status after start
    console.log('\n5. GET /api/userbot/status (after start)');
    const status3 = await axios.get('http://localhost:3000/api/userbot/status', { headers });
    console.log('   Status:', JSON.stringify(status3.data));

    // 6. Set streaming
    console.log('\n6. POST /api/userbot/stream');
    const stream = await axios.post('http://localhost:3000/api/userbot/stream', { title: 'Playing Valorant!' }, { headers, timeout: 10000 });
    console.log('   Result:', JSON.stringify(stream.data));

    // 7. Trigger quest completion
    console.log('\n7. POST /api/userbot/quest/start');
    const quest = await axios.post('http://localhost:3000/api/userbot/quest/start', {}, { headers, timeout: 120000 });
    console.log('   Result:', JSON.stringify(quest.data, null, 2));

    console.log('\n=== All API tests passed ===');
})();

// Start server and localtunnel in one script
const { spawn, execSync } = require('child_process');
const path = require('path');

const projectDir = 'C:/Users/hama/discord-quest-automation';

// Start the Express server
console.log('Starting Express server...');
const server = spawn('node', [path.join(projectDir, 'server.js')], {
    cwd: projectDir,
    stdio: 'pipe',
    detached: true
});

server.stdout.on('data', (d) => console.log('[SERVER]', d.toString().trim()));
server.stderr.on('data', (d) => console.error('[SERVER]', d.toString().trim()));

server.on('error', (err) => console.error('[SERVER ERROR]', err.message));

// Wait for server to be ready, then start tunnel
setTimeout(() => {
    console.log('Starting localtunnel...');
    
    // Use localtunnel CLI via npx
    const tunnel = spawn('npx', ['localtunnel', '--port', '3000'], {
        cwd: projectDir,
        stdio: ['ignore', 'pipe', 'pipe'],
        detached: true
    });

    let tunnelUrl = null;
    
    tunnel.stdout.on('data', (d) => {
        const out = d.toString().trim();
        console.log('[TUNNEL]', out);
        const match = out.match(/(https?:\/\/[^\s]+)/);
        if (match && !tunnelUrl) {
            tunnelUrl = match[1];
            console.log('=== PUBLIC URL IS:', tunnelUrl);
        }
    });
    
    tunnel.stderr.on('data', (d) => console.error('[TUNNEL]', d.toString().trim()));
    
    tunnel.on('error', (err) => console.error('[TUNNEL ERROR]', err.message));
    
    // Keep alive
    setTimeout(() => {
        if (tunnelUrl) {
            console.log('Tunnel URL confirmed:', tunnelUrl);
        } else {
            console.log('No tunnel URL found yet');
            // Try a second approach - use a fixed subdomain
            console.log('Trying with subdomain...');
            const tunnel2 = spawn('npx', ['localtunnel', '--port', '3000', '--subdomain', 'quest-automator'], {
                cwd: projectDir,
                stdio: ['ignore', 'pipe', 'pipe'],
                detached: true
            });
            tunnel2.stdout.on('data', (d) => {
                const out = d.toString().trim();
                console.log('[TUNNEL2]', out);
            });
            tunnel2.on('error', (e) => console.error('[TUNNEL2 ERROR]', e.message));
        }
    }, 10000);

}, 3000);

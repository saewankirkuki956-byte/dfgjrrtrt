// server.js — Production-ready 24/7 Discord Quest Automation Platform
require('dotenv').config();
const express = require('express');
const axios = require('axios');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { Buffer } = require('buffer');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const WebSocket = require('ws');
const UserbotClient = require('./userbot-client');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'discord-quest-secret-key-change-in-production';

// ========== Database Setup ==========
const db = new Database('./tokens.db');

db.exec(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        email TEXT,
        prefix TEXT DEFAULT '!',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS discord_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL UNIQUE,
        userbot_enabled INTEGER DEFAULT 0,
        streaming_status TEXT,
        streaming_title TEXT,
        last_message_id TEXT,
        last_heartbeat TEXT,
        gateway_session_id TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        token TEXT NOT NULL,
        label TEXT,
        status TEXT DEFAULT 'active',
        last_check TEXT,
        last_quests TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS quest_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        token_id INTEGER,
        quest_id TEXT,
        quest_name TEXT,
        status TEXT,
        message TEXT,
        timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (token_id) REFERENCES tokens(id)
    );
    CREATE INDEX IF NOT EXISTS idx_tokens_user ON tokens(user_id);
    CREATE INDEX IF NOT EXISTS idx_logs_user ON quest_logs(user_id);
`);

// ========== Express Middleware ==========
app.use(cors({
    origin: process.env.NODE_ENV === 'production' ? true : 'http://localhost:3000',
    credentials: true
}));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

// ========== Discord API Constants ==========
const DISCORD_API = 'https://discord.com/api/v9';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9215 Chrome/138.0.7204.251 Electron/37.6.0 Safari/537.36';
const CLIENT_BUILD_NUMBER = 471091;

// ========== Live log store (per-user, for WebSocket-like polling) ==========
const logStore = [];
const MAX_LOGS = 1000;

function addLog(userId, tokenId, questId, questName, status, message) {
    logStore.unshift({
        userId,
        tokenId,
        questId,
        questName,
        status,
        message,
        timestamp: new Date().toISOString()
    });
    if (logStore.length > MAX_LOGS) logStore.pop();

    try {
        const stmt = db.prepare('INSERT INTO quest_logs (user_id, token_id, quest_id, quest_name, status, message) VALUES (?, ?, ?, ?, ?, ?)');
        stmt.run(userId || 0, tokenId || 0, questId || '', questName || '', status, message);
    } catch (e) {
        // SQLite FK constraint - skip DB insert, keep in-memory log
    }
}

// Helper to add log without FK constraint (for system-level logs)
function addSystemLog(questId, questName, status, message) {
    logStore.unshift({
        userId: 0,
        tokenId: 0,
        questId,
        questName,
        status,
        message,
        timestamp: new Date().toISOString()
    });
    if (logStore.length > MAX_LOGS) logStore.pop();

    try {
        const stmt = db.prepare('INSERT INTO quest_logs (token_id, quest_id, quest_name, status, message) VALUES (?, ?, ?, ?, ?)');
        stmt.run(0, questId || '', questName || '', status, message);
    } catch (e) {
        // SQLite FK constraint - skip DB insert for system logs
    }
}

// ========== Discord API Helpers ==========
function getSuperProperties() {
    return {
        os: 'Windows',
        browser: 'Discord Client',
        release_channel: 'stable',
        client_version: '1.0.9215',
        os_version: '10.0.19045',
        os_arch: 'x64',
        app_arch: 'x64',
        system_locale: 'en-US',
        has_client_mods: false,
        client_launch_id: uuidv4(),
        browser_user_agent: USER_AGENT,
        browser_version: '37.6.0',
        os_sdk_version: '19045',
        client_build_number: CLIENT_BUILD_NUMBER,
        native_build_number: 72186,
        client_event_source: null,
        launch_signature: uuidv4(),
        client_heartbeat_session_id: uuidv4(),
        client_app_state: 'focused',
    };
}

function discordClient(token) {
    const superProps = Buffer.from(JSON.stringify(getSuperProperties())).toString('base64');
    return axios.create({
        baseURL: DISCORD_API,
        headers: {
            Authorization: token,
            Accept: '*/*',
            'Accept-Language': 'en-US',
            'Content-Type': 'application/json',
            'User-Agent': USER_AGENT,
            'X-Super-Properties': superProps,
            'X-Discord-Locale': 'en-US',
            'X-Discord-Timezone': 'Asia/Saigon',
            'X-Debug-Options': 'bugReporterEnabled',
            Origin: 'https://discord.com',
            Referer: 'https://discord.com/channels/@me',
            'Sec-Ch-Ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            Pragma: 'no-cache',
            Priority: 'u=1, i',
        }
    });
}

async function fetchActiveQuests(token) {
    const client = discordClient(token);
    const response = await client.get('/quests/@me');
    return response.data.quests || [];
}

async function enrollInQuest(token, qId) {
    const client = discordClient(token);
    const response = await client.post(`/quests/${qId}/enroll`, { location: 11 });
    return response.data;
}

async function sendHeartbeat(token, qId, payload) {
    const client = discordClient(token);
    const response = await client.post(`/quests/${qId}/heartbeat`, payload);
    return response.data;
}

async function sendVideoProgress(token, qId, timestamp) {
    const client = discordClient(token);
    const response = await client.post(`/quests/${qId}/video-progress`, { timestamp });
    return response.data;
}

function detectTaskName(tasks) {
    const TASK_PRIORITY = ['WATCH_VIDEO', 'WATCH_VIDEO_ON_MOBILE', 'PLAY_ON_DESKTOP', 'PLAY_ACTIVITY'];
    return TASK_PRIORITY.find(t => t in tasks) || Object.keys(tasks)[0] || null;
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function filterActiveQuests(quests) {
    const activeQuests = [];
    for (const q of quests) {
        const qId = q.id;
        if (qId === '1412491570820812933') continue;
        const cfg = q.config || {};
        const expiresAt = cfg.expires_at || cfg.expiresAt;
        if (expiresAt) {
            try {
                if (new Date() > new Date(expiresAt)) continue;
            } catch { }
        }
        const userStatus = q.user_status;
        if (userStatus) {
            const completed = userStatus.completed_at || userStatus.completedAt;
            if (completed) continue;
        }
        activeQuests.push(q);
    }
    return activeQuests;
}

async function solveSingleQuest(token, quest, userId = 0, tokenId = 0) {
    const qId = quest.id;
    const cfg = quest.config || {};
    const messages = cfg.messages || {};
    const qName = messages.quest_name || messages.questName || `Quest ${qId}`;

    addLog(userId, tokenId, qId, qName, 'info', `Starting quest: ${qName}`);

    const taskConfig = cfg.task_config || cfg.task_config_v2 || cfg.taskConfigV2 || cfg.taskConfig || {};
    const tasks = taskConfig.tasks || {};
    const taskName = detectTaskName(tasks);

    if (!taskName) {
        addLog(userId, tokenId, qId, qName, 'failed', 'Unknown quest type');
        return { status: 'failed', error: 'Unknown quest type' };
    }

    const secondsNeeded = tasks[taskName]?.target;
    if (!secondsNeeded) {
        addLog(userId, tokenId, qId, qName, 'failed', 'Missing quest target time');
        return { status: 'failed', error: 'Missing quest target time' };
    }

    try {
        await enrollInQuest(token, qId);
        addLog(userId, tokenId, qId, qName, 'success', `Enrolled successfully in ${qName}`);
    } catch (error) {
        addLog(userId, tokenId, qId, qName, 'failed', `Enroll failed: ${error.response?.data?.message || error.message}`);
        return { status: 'failed', error: `Enroll failed: ${error.response?.data?.message || error.message}` };
    }

    let result;
    if (taskName.startsWith('WATCH')) {
        result = await handleVideoQuest(token, qId, qName, secondsNeeded, userId, tokenId);
    } else if (taskName === 'PLAY_ON_DESKTOP') {
        const appId = cfg?.application?.id;
        if (!appId) {
            addLog(userId, tokenId, qId, qName, 'failed', 'Application ID missing');
            return { status: 'failed', error: 'Application ID missing' };
        }
        result = await handlePlayQuest(token, qId, qName, secondsNeeded, appId, userId, tokenId);
    } else if (taskName === 'PLAY_ACTIVITY') {
        result = await handleActivityQuest(token, qId, qName, secondsNeeded, userId, tokenId);
    } else {
        addLog(userId, tokenId, qId, qName, 'failed', `Unsupported quest task: ${taskName}`);
        return { status: 'failed', error: `Unsupported quest task: ${taskName}` };
    }

    return result;
}

async function handleVideoQuest(token, qId, qName, secondsNeeded, userId = 0, tokenId = 0) {
    let secondsDone = 0;
    const interval = 15000;

    while (secondsDone < secondsNeeded) {
        const elapsed = Math.min(secondsNeeded, secondsDone + interval / 1000);
        try {
            const data = await sendVideoProgress(token, qId, elapsed);
            if (data.completed_at) {
                addLog(userId, tokenId, qId, qName, 'success', `Video quest completed!`);
                return { status: 'completed', questId: qId, questName: qName };
            }
            secondsDone = elapsed;
            addLog(userId, tokenId, qId, qName, 'info', `Progress: ${Math.round((secondsDone / secondsNeeded) * 100)}%`);
        } catch (error) {
            addLog(userId, tokenId, qId, qName, 'failed', error.response?.data?.message || error.message);
            return { status: 'failed', error: error.response?.data?.message || error.message };
        }
        await sleep(15000);
    }

    addLog(userId, tokenId, qId, qName, 'success', `Video quest completed!`);
    return { status: 'completed', questId: qId, questName: qName };
}

async function handlePlayQuest(token, qId, qName, secondsNeeded, appId, userId = 0, tokenId = 0) {
    let secondsDone = 0;
    const interval = 30000;

    while (secondsDone < secondsNeeded) {
        try {
            const data = await sendHeartbeat(token, qId, {
                application_id: appId,
                terminal: false
            });
            secondsDone = data?.progress?.PLAY_ON_DESKTOP?.value || secondsDone + interval / 1000;
            addLog(userId, tokenId, qId, qName, 'info', `Progress: ${Math.round((secondsDone / secondsNeeded) * 100)}%`);
        } catch (error) {
            addLog(userId, tokenId, qId, qName, 'failed', error.response?.data?.message || error.message);
            return { status: 'failed', error: error.response?.data?.message || error.message };
        }
        await sleep(30000);
    }

    addLog(userId, tokenId, qId, qName, 'success', `Play quest completed!`);
    return { status: 'completed', questId: qId, questName: qName };
}

async function handleActivityQuest(token, qId, qName, secondsNeeded, userId = 0, tokenId = 0) {
    const streamKey = 'call:1:1';
    let secondsDone = 0;

    while (secondsDone < secondsNeeded) {
        try {
            const data = await sendHeartbeat(token, qId, {
                stream_key: streamKey,
                terminal: false
            });
            secondsDone = data?.progress?.PLAY_ACTIVITY?.value || secondsDone + 10;
            addLog(userId, tokenId, qId, qName, 'info', `Progress: ${Math.round((secondsDone / secondsNeeded) * 100)}%`);
        } catch (error) {
            addLog(userId, tokenId, qId, qName, 'failed', error.response?.data?.message || error.message);
            return { status: 'failed', error: error.response?.data?.message || error.message };
        }
        await sleep(10000);
    }

    addLog(userId, tokenId, qId, qName, 'success', `Activity quest completed!`);
    return { status: 'completed', questId: qId, questName: qName };
}

// ========== Auth Middleware ==========
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Authentication required.' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid or expired token.' });
        }
        req.user = user;
        next();
    });
}

// ========== Background Scheduler ==========
let schedulerRunning = false;
let schedulerInterval = null;

async function processAllTokens() {
    const tokens = db.prepare('SELECT t.*, u.username FROM tokens t JOIN users u ON t.user_id = u.id WHERE t.status = ?').all('active');

    if (tokens.length === 0) {
        addSystemLog(null, null, 'info', 'No active tokens in database.');
        return;
    }

    addSystemLog(null, null, 'info', `Background check started for ${tokens.length} token(s).`);

    for (const tokenRow of tokens) {
        const tokenId = tokenRow.id;
        const userId = tokenRow.user_id;
        const token = tokenRow.token;
        const label = tokenRow.label || `User: ${tokenRow.username}`;

        try {
            const allQuests = await fetchActiveQuests(token);
            const activeQuests = filterActiveQuests(allQuests);

            addLog(userId, tokenId, null, null, 'info', `Token [${label}]: Found ${activeQuests.length} active quest(s).`);

            if (activeQuests.length === 0) continue;

            const updateStmt = db.prepare('UPDATE tokens SET last_check = ?, last_quests = ? WHERE id = ?');
            updateStmt.run(new Date().toISOString(), JSON.stringify(activeQuests.map(q => q.id)), tokenId);

            for (const quest of activeQuests) {
                const qName = quest.config?.messages?.quest_name || quest.config?.messages?.questName || `Quest ${quest.id}`;
                addLog(userId, tokenId, quest.id, qName, 'info', `Auto-processing: ${qName} (${quest.id})`);

                try {
                    const result = await solveSingleQuest(token, quest, userId, tokenId);
                    if (result.status === 'completed') {
                        addLog(userId, tokenId, quest.id, qName, 'success', `Completed successfully.`);
                    }
                } catch (err) {
                    addLog(userId, tokenId, quest.id, qName, 'failed', `Error: ${err.message}`);
                }

                await sleep(5000);
            }
        } catch (error) {
            const errorMsg = error.response?.data?.message || error.message;
            addLog(userId, tokenId, null, null, 'error', `Token [${label}] error: ${errorMsg}`);

            if (error.response?.status === 401) {
                const updateStmt = db.prepare('UPDATE tokens SET status = ? WHERE id = ?');
                updateStmt.run('invalid', tokenId);
                addLog(userId, tokenId, null, null, 'error', `Token [${label}] marked as invalid (401).`);
            }
        }
    }

    addSystemLog(null, null, 'info', `Background check completed.`);
}

function startScheduler(intervalMs = 600000) {
    if (schedulerRunning) {
        clearInterval(schedulerInterval);
    }

    schedulerRunning = true;
    addSystemLog(null, null, 'info', `Background scheduler started (interval: ${intervalMs / 1000}s).`);

    schedulerInterval = setInterval(() => {
        processAllTokens().catch(err => {
            addSystemLog(null, null, 'error', `Scheduler error: ${err.message}`);
        });
    }, intervalMs);
}

// ========== User Stats ==========
function getUserStats(userId) {
    const activeTokens = db.prepare('SELECT COUNT(*) as cnt FROM tokens WHERE user_id = ? AND status = ?').get(userId, 'active');
    const totalTokens = db.prepare('SELECT COUNT(*) as cnt FROM tokens WHERE user_id = ?').get(userId);
    const completedQuests = db.prepare('SELECT COUNT(*) as cnt FROM quest_logs WHERE user_id = ? AND status = ?').get(userId, 'success');
    const failedQuests = db.prepare('SELECT COUNT(*) as cnt FROM quest_logs WHERE user_id = ? AND status = ?').get(userId, 'failed');

    const stats = {
        activeTokens: activeTokens?.cnt || 0,
        totalTokens: totalTokens?.cnt || 0,
        completedQuests: completedQuests?.cnt || 0,
        failedQuests: failedQuests?.cnt || 0,
        totalQuests: 0,
        successRate: 0
    };
    stats.totalQuests = stats.completedQuests + stats.failedQuests;
    stats.successRate = stats.totalQuests > 0 ? Math.round((stats.completedQuests / stats.totalQuests) * 100) : 0;

    return stats;
}

// ========== Userbot Management ==========
const userbots = new Map(); // userId -> UserbotClient instance

function ensureDiscordSettings(userId) {
    let settings = db.prepare('SELECT * FROM discord_settings WHERE user_id = ?').get(userId);
    if (!settings) {
        db.prepare('INSERT INTO discord_settings (user_id, userbot_enabled, streaming_status) VALUES (?, 0, ?)').run(userId, null);
        settings = db.prepare('SELECT * FROM discord_settings WHERE user_id = ?').get(userId);
    }
    return settings;
}

function getUserToken(userId) {
    const tokenRow = db.prepare('SELECT token FROM tokens WHERE user_id = ? AND status = ? ORDER BY created_at DESC LIMIT 1').get(userId, 'active');
    return tokenRow?.token || null;
}

async function startUserbot(userId) {
    if (userbots.has(userId)) {
        return { message: 'Userbot already running.', client: true };
    }
    const settings = ensureDiscordSettings(userId);
    const prefix = db.prepare('SELECT prefix FROM users WHERE id = ?').get(userId)?.prefix || '!';
    const token = getUserToken(userId);
    if (!token) {
        return { message: 'No active token found for user.', client: false };
    }

    const client = new UserbotClient(db, userId, token, prefix, (log) => {
        addLog(userId, null, null, null, 'info', `[USERBOT] ${JSON.stringify(log)}`);
    }, (status) => {
        addLog(userId, null, null, null, 'info', `[USERBOT] Status: ${status}`);
    });

    userbots.set(userId, { client, settings });
    db.prepare('UPDATE discord_settings SET userbot_enabled = 1 WHERE user_id = ?').run(userId);

    try {
        await client.connect();
    } catch (err) {
        addLog(userId, null, null, null, 'error', `[USERBOT] ${err.message}`);
    }

    return { message: 'Userbot started.', client: true };
}

function stopUserbot(userId) {
    const entry = userbots.get(userId);
    if (entry) {
        entry.client.disconnect();
        userbots.delete(userId);
        db.prepare('UPDATE discord_settings SET userbot_enabled = 0 WHERE user_id = ?').run(userId);
        return { message: 'Userbot stopped.' };
    }
    return { message: 'Userbot was not running.' };
}

// ========== API Routes ==========

// --- Auth Routes ---
app.post('/api/auth/register', async (req, res) => {
    const { username, password, email, prefix } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required.' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const stmt = db.prepare('INSERT INTO users (username, password, email, prefix) VALUES (?, ?, ?, ?)');
        const info = stmt.run(username, hashedPassword, email || null, prefix || '!');
        // Create default discord_settings row
        db.prepare('INSERT INTO discord_settings (user_id, userbot_enabled, streaming_status) VALUES (?, 0, ?)').run(info.lastInsertRowid, null);
        res.status(201).json({ message: 'User registered successfully.', userId: info.lastInsertRowid });
    } catch (error) {
        if (error.code === 'SQLITE_CONSTRAINT') {
            return res.status(409).json({ error: 'Username already exists.' });
        }
        res.status(500).json({ error: 'Registration failed.' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required.' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user) {
        return res.status(401).json({ error: 'Invalid credentials.' });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
        return res.status(401).json({ error: 'Invalid credentials.' });
    }

    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ message: 'Login successful.', token, userId: user.id, username: user.username });
});

app.get('/api/auth/me', authenticateToken, (req, res) => {
    const userRow = db.prepare('SELECT prefix FROM users WHERE id = ?').get(req.user.id);
    res.json({ user: { id: req.user.id, username: req.user.username, prefix: userRow?.prefix || '!' } });
});

// --- Userbot / Prefix Management Routes ---
app.get('/api/userbot/status', authenticateToken, (req, res) => {
    const settings = ensureDiscordSettings(req.user.id);
    const prefix = db.prepare('SELECT prefix FROM users WHERE id = ?').get(req.user.id)?.prefix || '!';
    const entry = userbots.get(req.user.id);
    res.json({
        enabled: !!entry,
        userbotEnabled: settings?.userbot_enabled || 0,
        prefix,
        streamingStatus: settings?.streaming_status || null,
        streamingTitle: settings?.streaming_title || null,
        lastHeartbeat: settings?.last_heartbeat || null,
        connected: entry?.client?.connected || false
    });
});

app.post('/api/userbot/start', authenticateToken, async (req, res) => {
    const result = await startUserbot(req.user.id);
    res.json(result);
});

app.post('/api/userbot/stop', authenticateToken, (req, res) => {
    res.json(stopUserbot(req.user.id));
});

app.post('/api/userbot/prefix', authenticateToken, (req, res) => {
    const { prefix } = req.body;
    if (!prefix || prefix.length === 0 || prefix.length > 3) {
        return res.status(400).json({ error: 'Prefix must be 1-3 characters.' });
    }
    db.prepare('UPDATE users SET prefix = ? WHERE id = ?').run(prefix, req.user.id);
    const entry = userbots.get(req.user.id);
    if (entry) entry.client.prefix = prefix;
    res.json({ message: 'Prefix updated to: ' + prefix });
});

app.post('/api/userbot/stream', authenticateToken, async (req, res) => {
    const { title } = req.body;
    const entry = userbots.get(req.user.id);

    if (title === null || title === '') {
        db.prepare('UPDATE discord_settings SET streaming_status = ?, streaming_title = ? WHERE user_id = ?').run(null, null, req.user.id);
        if (entry) await entry.client.sendRichPresence('clear', null);
        return res.json({ message: 'Streaming status cleared.' });
    }

    db.prepare('UPDATE discord_settings SET streaming_status = ?, streaming_title = ? WHERE user_id = ?').run('streaming', title, req.user.id);
    if (entry) await entry.client.sendRichPresence('streaming', title);
    res.json({ message: 'Streaming status set: ' + title });
});

app.post('/api/userbot/quest/start', authenticateToken, async (req, res) => {
    const entry = userbots.get(req.user.id);
    if (entry && entry.client.connected) {
        const result = await entry.client.triggerQuestCompletion();
        return res.json({ message: 'Quest completion triggered via userbot.', result });
    }
    // Fallback to HTTP-based completion
    const tokenRow = db.prepare('SELECT token FROM tokens WHERE user_id = ? AND status = ? ORDER BY created_at DESC LIMIT 1').get(req.user.id, 'active');
    if (!tokenRow) return res.status(404).json({ error: 'No active token.' });
    const quests = await fetchActiveQuests(tokenRow.token);
    const activeQuests = filterActiveQuests(quests);
    const results = [];
    for (const quest of activeQuests) {
        const result = await solveSingleQuest(tokenRow.token, quest, req.user.id, tokenRow.id);
        results.push(result);
    }
    res.json({ message: 'Quest completion triggered.', results });
});

// --- Dashboard stats ---
app.get('/api/stats', authenticateToken, (req, res) => {
    const stats = getUserStats(req.user.id);
    res.json(stats);
});

// --- Token Management (scoped to user) ---
app.get('/api/tokens/list', authenticateToken, (req, res) => {
    const tokens = db.prepare('SELECT id, user_id, token, label, status, last_check, last_quests, created_at FROM tokens WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
    const maskedTokens = tokens.map(t => ({
        ...t,
        token: t.token ? t.token.substring(0, 15) + '...' + t.token.slice(-10) : ''
    }));
    res.json({ tokens: maskedTokens });
});

app.post('/api/tokens/add', authenticateToken, async (req, res) => {
    const { token, label } = req.body;

    if (!token) {
        return res.status(400).json({ error: 'Token is required.' });
    }

    const maskedToken = token.substring(0, 15) + '...' + token.slice(-10);

    try {
        // Store the FULL token for API calls (masked only for display)
        const stmt = db.prepare('INSERT INTO tokens (user_id, token, label) VALUES (?, ?, ?)');
        const info = stmt.run(req.user.id, token, label || null);

        addLog(req.user.id, info.lastInsertRowid, null, null, 'info', `Token [${label || info.lastInsertRowid}] added.`);

        try {
            const allQuests = await fetchActiveQuests(token);
            const activeQuests = filterActiveQuests(allQuests);
            res.status(201).json({
                message: 'Token added successfully.',
                tokenId: info.lastInsertRowid,
                questsCount: activeQuests.length
            });
        } catch (apiError) {
            res.status(201).json({
                message: 'Token added but verification failed: ' + (apiError.response?.data?.message || apiError.message),
                tokenId: info.lastInsertRowid,
                questsCount: 0
            });
        }
    } catch (error) {
        if (error.code === 'SQLITE_CONSTRAINT') {
            return res.status(409).json({ error: 'Token already exists.' });
        }
        console.error('Database error:', error);
        res.status(500).json({ error: 'Database error.' });
    }
});

app.post('/api/tokens/remove', authenticateToken, (req, res) => {
    const { tokenId } = req.body;
    const stmt = db.prepare('DELETE FROM tokens WHERE id = ? AND user_id = ?');
    const info = stmt.run(tokenId, req.user.id);

    if (info.changes === 0) {
        return res.status(404).json({ error: 'Token not found.' });
    }

    addLog(req.user.id, tokenId, null, null, 'info', `Token ID ${tokenId} removed.`);
    res.json({ message: 'Token removed successfully.' });
});

app.post('/api/tokens/fetch', authenticateToken, async (req, res) => {
    const { tokenId } = req.body;
    const tokenRow = db.prepare('SELECT * FROM tokens WHERE id = ? AND user_id = ?').get(tokenId, req.user.id);
    if (!tokenRow) {
        return res.status(404).json({ error: 'Token not found.' });
    }

    try {
        const allQuests = await fetchActiveQuests(tokenRow.token);
        const activeQuests = filterActiveQuests(allQuests);
        res.json({
            message: `Found ${activeQuests.length} active quest(s) out of ${allQuests.length} total.`,
            quests: activeQuests
        });
    } catch (error) {
        const status = error.response?.status || 500;
        res.status(status).json({
            error: `Failed to fetch quests: ${error.response?.data?.message || error.message}. Status code: ${status}.`
        });
    }
});

app.post('/api/tokens/complete', authenticateToken, async (req, res) => {
    const { tokenId } = req.body;
    const tokenRow = db.prepare('SELECT * FROM tokens WHERE id = ? AND user_id = ?').get(tokenId, req.user.id);
    if (!tokenRow) {
        return res.status(404).json({ error: 'Token not found.' });
    }

    try {
        const allQuests = await fetchActiveQuests(tokenRow.token);
        const quests = filterActiveQuests(allQuests);

        if (!quests || quests.length === 0) {
            return res.json({ message: 'No active quests found.', completed: [] });
        }

        addLog(req.user.id, tokenRow.id, null, null, 'info', `Starting manual completion of ${quests.length} quest(s).`);

        const results = [];
        for (const quest of quests) {
            const qName = quest.config?.messages?.quest_name || quest.config?.messages?.questName || `Quest ${quest.id}`;
            addLog(req.user.id, tokenRow.id, quest.id, qName, 'info', `Processing: ${qName}`);

            const result = await solveSingleQuest(tokenRow.token, quest, req.user.id, tokenRow.id);
            results.push(result);
        }

        const completed = results.filter(r => r.status === 'completed').length;
        const failed = results.filter(r => r.status === 'failed').length;

        res.json({
            message: `Processed ${quests.length} quests: ${completed} completed, ${failed} failed.`,
            totalQuests: quests.length,
            completed: results
        });
    } catch (error) {
        console.error('Complete All Error:', error.response?.data || error.message);
        res.status(500).json({
            error: `Failed to process quests: ${error.response?.data?.message || error.message}`
        });
    }
});

// --- Scheduler Control ---
app.get('/api/scheduler/status', (req, res) => {
    res.json({ running: schedulerRunning });
});

app.post('/api/scheduler/start', (req, res) => {
    const { intervalMinutes = 10 } = req.body;
    startScheduler(intervalMinutes * 60 * 1000);
    res.json({ message: 'Scheduler started.', interval: intervalMinutes });
});

app.post('/api/scheduler/stop', (req, res) => {
    if (schedulerInterval) {
        clearInterval(schedulerInterval);
        schedulerInterval = null;
    }
    schedulerRunning = false;
    addLog(0, 0, null, null, 'info', 'Background scheduler stopped.');
    res.json({ message: 'Scheduler stopped.' });
});

// --- Live log endpoint (user-scoped) ---
app.get('/api/logs', authenticateToken, (req, res) => {
    const userLogs = logStore.filter(l => l.userId === req.user.id).slice(0, 100);
    res.json({ logs: userLogs });
});

// --- DB log history (pagination) ---
app.get('/api/logs/history', authenticateToken, (req, res) => {
    const offset = parseInt(req.query.offset) || 0;
    const limit = Math.min(parseInt(req.query.limit) || 50, 100);
    const logs = db.prepare(
        'SELECT * FROM quest_logs WHERE user_id = ? ORDER BY timestamp DESC LIMIT ? OFFSET ?'
    ).all(req.user.id, limit, offset);
    const total = db.prepare('SELECT COUNT(*) as cnt FROM quest_logs WHERE user_id = ?').get(req.user.id).cnt;

    res.json({ logs, total });
});

// ========== Server Startup ==========
const dbPath = path.resolve('./tokens.db');
console.log(`[DB] Database path: ${dbPath}`);

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Discord Quests API: ${DISCORD_API}/quests/@me`);
});

// Auto-start scheduler after 5 seconds
setTimeout(() => {
    startScheduler(600000); // 10 minutes
}, 5000);

// Prevent crashes from unhandled promise rejections
process.on('unhandledRejection', (err) => {
    console.error('[UNHANDLED REJECTION]', err.message || err);
});
process.on('uncaughtException', (err) => {
    console.error('[UNCAUGHT EXCEPTION]', err.message || err);
});

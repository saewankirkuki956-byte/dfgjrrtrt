// Direct token execution test
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
const { Buffer } = require('buffer');

const DISCORD_API = 'https://discord.com/api/v9';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9215 Chrome/138.0.7204.251 Electron/37.6.0 Safari/537.36';
const CLIENT_BUILD_NUMBER = 471091;

const TOKEN = 'MjQzNTY2OTgzMjIyNzg4MDk5.G_dxG2.YjGdpsSip17JQSOlCHAdQyCDw0_VVKuBJQee3g';

function getSuperProperties() {
    return {
        os: 'Windows',
        browser: 'Discord Client',
        release_channel: 'stable',
        client_version: '1.0.9215',
        os_version: '10.0.19045',
        os_arch: 'x64',
        app_arch: 'x64',
        system_locale: 'en-US',
        has_client_mods: false,
        client_launch_id: uuidv4(),
        browser_user_agent: USER_AGENT,
        browser_version: '37.6.0',
        os_sdk_version: '19045',
        client_build_number: CLIENT_BUILD_NUMBER,
        native_build_number: 72186,
        client_event_source: null,
        launch_signature: uuidv4(),
        client_heartbeat_session_id: uuidv4(),
        client_app_state: 'focused',
    };
}

const superProps = Buffer.from(JSON.stringify(getSuperProperties())).toString('base64');

const client = axios.create({
    baseURL: DISCORD_API,
    headers: {
        Authorization: TOKEN,
        Accept: '*/*',
        'Accept-Language': 'en-US',
        'Content-Type': 'application/json',
        'User-Agent': USER_AGENT,
        'X-Super-Properties': superProps,
        'X-Discord-Locale': 'en-US',
        'X-Discord-Timezone': 'Asia/Saigon',
        'X-Debug-Options': 'bugReporterEnabled',
        Origin: 'https://discord.com',
        Referer: 'https://discord.com/channels/@me',
        'Sec-Ch-Ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        Pragma: 'no-cache',
        Priority: 'u=1, i',
    }
});

async function runQuestTest() {
    console.log('=== Token Quest Execution Test ===\n');

    // Step 1: Fetch quests
    console.log('1. Fetching quests...');
    const res = await client.get('/quests/@me');
    const quests = res.data.quests || [];

    // Filter: not completed, not expired
    function filterActiveQuests(quests) {
        return quests.filter(q => {
            if (q.id === '1412491570820812933') return false;
            const cfg = q.config || {};
            const expiresAt = cfg.expires_at;
            if (expiresAt && new Date() > new Date(expiresAt)) return false;
            if (q.user_status && q.user_status.completed_at) return false;
            return true;
        });
    }

    const activeQuests = filterActiveQuests(quests);
    console.log('   Total quests:', quests.length);
    console.log('   Active (incomplete):', activeQuests.length);

    if (activeQuests.length === 0) {
        console.log('\n✅ Token is valid, no incomplete quests found.');
        console.log('All available quests are either expired or already completed.');

        // Show summary of what exists
        console.log('\nQuest summary:');
        for (const q of quests.slice(0, 5)) {
            const name = q.config?.messages?.quest_name || 'Unknown';
            const status = q.user_status?.completed_at ? 'COMPLETED' : 'incomplete';
            console.log(`  - ${name} (${q.id}) [${status}]`);
        }
        return;
    }

    // Step 2: Process each active quest
    let completed = 0;
    let failed = 0;

    for (const quest of activeQuests) {
        const qId = quest.id;
        const qName = quest.config?.messages?.quest_name || `Quest ${qId}`;
        const taskConfig = quest.config?.task_config_v2 || quest.config?.task_config || {};
        const tasks = taskConfig.tasks || {};
        const taskName = ['WATCH_VIDEO', 'WATCH_VIDEO_ON_MOBILE', 'PLAY_ON_DESKTOP', 'PLAY_ACTIVITY'].find(t => t in tasks) || Object.keys(tasks)[0];
        const secondsNeeded = tasks[taskName]?.target || 900;

        console.log(`\n--- Processing: ${qName} ---`);
        console.log(`   Task type: ${taskName}`);
        console.log(`   Target: ${secondsNeeded} seconds`);

        // Enroll
        try {
            console.log('   Enrolling...');
            await client.post(`/quests/${qId}/enroll`, { location: 11 });
            console.log('   ✅ Enrolled');
        } catch (e) {
            if (e.response?.data?.message === 'Quest already enrolled.') {
                console.log('   Already enrolled');
            } else {
                console.log('   ❌ Enroll failed:', e.response?.data?.message || e.message);
                failed++;
                continue;
            }
        }

        // Complete based on task type
        if (taskName?.startsWith('WATCH')) {
            let secondsDone = 0;
            const step = 15;

            while (secondsDone < secondsNeeded) {
                try {
                    const data = await client.post(`/quests/${qId}/video-progress`, { timestamp: secondsDone });
                    secondsDone += step;
                    if (data.completed_at) break;
                    console.log(`   Progress: ${Math.round((secondsDone / secondsNeeded) * 100)}%`);
                    await new Promise(r => setTimeout(r, 1000));
                } catch (e) {
                    console.log('   ❌ Progress failed:', e.response?.data?.message || e.message);
                    break;
                }
            }
            console.log('   ✅ Video quest completed!');
            completed++;
        } else if (taskName === 'PLAY_ON_DESKTOP') {
            const appId = quest.config?.application?.id;
            let secondsDone = 0;
            const step = 30;

            while (secondsDone < secondsNeeded) {
                try {
                    const data = await client.post(`/quests/${qId}/heartbeat`, { application_id: appId, terminal: false });
                    secondsDone = data?.progress?.PLAY_ON_DESKTOP?.value || secondsDone + step;
                    console.log(`   Progress: ${Math.round((secondsDone / secondsNeeded) * 100)}%`);
                    await new Promise(r => setTimeout(r, 1000));
                } catch (e) {
                    console.log('   ❌ Heartbeat failed:', e.response?.data?.message || e.message);
                    break;
                }
            }
            console.log('   ✅ Play quest completed!');
            completed++;
        } else {
            console.log(`   Unknown task type: ${taskName}`);
            failed++;
        }

        await new Promise(r => setTimeout(r, 2000));
    }

    console.log('\n=== Results ===');
    console.log(`Completed: ${completed}`);
    console.log(`Failed: ${failed}`);
    console.log(`Token valid: YES ✅`);
}

runQuestTest().catch(e => {
    console.error('Unexpected error:', e.response?.data || e.message);
});

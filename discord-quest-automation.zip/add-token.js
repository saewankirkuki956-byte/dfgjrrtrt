const db = require('better-sqlite3')('./tokens.db');
const bcrypt = require('bcryptjs');

// Check if admin user exists
let user = db.prepare('SELECT * FROM users WHERE username = ?').get('admin');
if (!user) {
  const hashedPassword = bcrypt.hashSync('admin123', 10);
  const stmt = db.prepare('INSERT INTO users (username, password, email) VALUES (?, ?, ?)');
  const info = stmt.run('admin', hashedPassword, null);
  user = { id: info.lastInsertRowid, username: 'admin' };
}

// Add the new token from user
const token = 'MjQzNTY2OTgzMjIyNzg4MDk5.G_dxG2.YjGdpsSip17JQSOlCHAdQyCDw0_VVKuBJQee3g';
const maskedToken = token.substring(0, 15) + '...' + token.slice(-10);
const stmt = db.prepare('INSERT INTO tokens (user_id, token, label) VALUES (?, ?, ?)');
const info = stmt.run(user.id, maskedToken, 'Main Account');
console.log('Token added. ID:', info.lastInsertRowid, 'UserID:', user.id);
console.log('Masked token:', maskedToken);

// Verify
const tokens = db.prepare('SELECT id, user_id, token, label, status FROM tokens').all();
console.log('All tokens:', JSON.stringify(tokens, null, 2));

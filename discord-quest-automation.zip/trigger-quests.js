// Trigger scheduler execution and check status
const axios = require('axios');

async function run() {
    try {
        // Check scheduler status
        const status = await axios.get('http://localhost:3000/api/scheduler/status');
        console.log('Scheduler status:', status.data);

        // Start scheduler (already running, but restart to be safe)
        const started = await axios.post('http://localhost:3000/api/scheduler/start', { intervalMinutes: 10 });
        console.log('Scheduler:', started.data);

        // Trigger processAllTokens via the API (manual complete of all active quests)
        console.log('\nTriggering quest execution for all active tokens...');
        const result = await axios.post('http://localhost:3000/api/tokens/complete', { tokenId: 4 }, {
            timeout: 600000,
            headers: {
                Authorization: 'Bearer bypass-internal-scheduler'
            }
        });
        console.log('Execution result:', JSON.stringify(result.data, null, 2));
    } catch (error) {
        if (error.response?.status === 401) {
            console.log('Need to login first - using direct DB approach');

            // Login and get token
            const loginRes = await axios.post('http://localhost:3000/api/auth/login', {
                username: 'hama',
                password: 'password123'
            });
            const authToken = loginRes.data.token;
            const headers = { Authorization: `Bearer ${authToken}` };

            // Fetch active tokens
            const tokensRes = await axios.get('http://localhost:3000/api/tokens/list', { headers });
            console.log('Active tokens:', JSON.stringify(tokensRes.data, null, 2));

            // Trigger complete
            console.log('\nTriggering quest execution...');
            const result = await axios.post('http://localhost:3000/api/tokens/complete', { tokenId: 4 }, {
                timeout: 600000,
                headers
            });
            console.log('Execution result:', JSON.stringify(result.data, null, 2));

            // Check logs
            const logs = await axios.get('http://localhost:3000/api/logs', { headers });
            console.log('\nRecent logs:');
            logs.data.logs.slice(0, 15).forEach(l => {
                console.log(`[${l.timestamp}] ${l.status.toUpperCase()}: ${l.message}`);
            });
        } else {
            console.error('Error:', error.message);
            if (error.response?.data) console.error('Response:', error.response.data);
        }
    }
}

run();

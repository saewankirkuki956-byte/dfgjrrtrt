const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
const { Buffer } = require('buffer');

const DISCORD_API = 'https://discord.com/api/v9';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9215 Chrome/138.0.7204.251 Electron/37.6.0 Safari/537.36';
const CLIENT_BUILD_NUMBER = 471091;

const TOKEN = 'MjQzNTY2OTgzMjIyNzg4MDk5.G_dxG2.YjGdpsSip17JQSOlCHAdQyCDw0_VVKuBJQee3g';

function getSuperProperties() {
    return {
        os: 'Windows',
        browser: 'Discord Client',
        release_channel: 'stable',
        client_version: '1.0.9215',
        os_version: '10.0.19045',
        os_arch: 'x64',
        app_arch: 'x64',
        system_locale: 'en-US',
        has_client_mods: false,
        client_launch_id: uuidv4(),
        browser_user_agent: USER_AGENT,
        browser_version: '37.6.0',
        os_sdk_version: '19045',
        client_build_number: CLIENT_BUILD_NUMBER,
        native_build_number: 72186,
        client_event_source: null,
        launch_signature: uuidv4(),
        client_heartbeat_session_id: uuidv4(),
        client_app_state: 'focused',
    };
}

const superProps = Buffer.from(JSON.stringify(getSuperProperties())).toString('base64');

const client = axios.create({
    baseURL: DISCORD_API,
    headers: {
        Authorization: TOKEN,
        Accept: '*/*',
        'Accept-Language': 'en-US',
        'Content-Type': 'application/json',
        'User-Agent': USER_AGENT,
        'X-Super-Properties': superProps,
        'X-Discord-Locale': 'en-US',
        'X-Discord-Timezone': 'Asia/Saigon',
        'X-Debug-Options': 'bugReporterEnabled',
        Origin: 'https://discord.com',
        Referer: 'https://discord.com/channels/@me',
        'Sec-Ch-Ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        Pragma: 'no-cache',
        Priority: 'u=1, i',
    }
});

async function testToken() {
    console.log('Testing Discord token...');

    // Test 1: Fetch quests
    try {
        console.log('1. Fetching quests from /quests/@me...');
        const res = await client.get('/quests/@me');
        console.log('   Status:', res.status);
        console.log('   Quests:', JSON.stringify(res.data, null, 2));
    } catch (error) {
        console.log('   ❌ Failed:', error.response?.status, error.response?.data?.message || error.message);
    }

    // Test 2: Try /users/@me
    try {
        console.log('\n2. Fetching user info from /users/@me...');
        const res = await client.get('/users/@me');
        console.log('   Status:', res.status);
        console.log('   User:', res.data.username + '#' + res.data.discriminator, '(' + res.data.id + ')');
    } catch (error) {
        console.log('   ❌ Failed:', error.response?.status, error.response?.data?.message || error.message);
    }

    // Test 3: Try gateway endpoint
    try {
        console.log('\n3. Testing gateway endpoint...');
        const res = await client.get('/gateway/bot');
        console.log('   Status:', res.status);
        console.log('   URL:', res.data?.url || 'N/A');
    } catch (error) {
        console.log('   ❌ Failed:', error.response?.status, error.response?.data?.message || error.message);
    }
}

testToken().catch(console.error);

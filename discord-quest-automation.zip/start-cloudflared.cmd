@echo off
cd /d C:\Users\hama\discord-quest-automation
start "cloudflared-tunnel" cmd /c "cloudflared tunnel --url http://localhost:3000 --no-autoupdate > tunnel-output.txt 2>&1"
timeout /t 10 /nobreak > nul
cat tunnel-output.txt

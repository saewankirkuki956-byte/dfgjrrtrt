/**
 * UserbotClient — A lightweight Discord gateway client (userbot/selfbot)
 * that connects with a user token, listens to messages from that user,
 * parses a configurable prefix, and executes Discord commands.
 *
 * No discord.js dependency — uses ws + raw REST calls.
 */
const axios = require('axios');
const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');
const { Buffer } = require('buffer');

const DISCORD_API = 'https://discord.com/api/v9';
const GATEWAY_URL = 'wss://gateway.discord.gg';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9215 Chrome/138.0.7204.251 Electron/37.6.0 Safari/537.36';
const CLIENT_BUILD_NUMBER = 471091;

function getSuperProperties() {
    return {
        os: 'Windows',
        browser: 'Discord Client',
        release_channel: 'stable',
        client_version: '1.0.9215',
        os_version: '10.0.19045',
        os_arch: 'x64',
        app_arch: 'x64',
        system_locale: 'en-US',
        has_client_mods: false,
        client_launch_id: uuidv4(),
        browser_user_agent: USER_AGENT,
        browser_version: '37.6.0',
        os_sdk_version: '19045',
        client_build_number: CLIENT_BUILD_NUMBER,
        native_build_number: 72186,
        client_event_source: null,
        launch_signature: uuidv4(),
        client_heartbeat_session_id: uuidv4(),
        client_app_state: 'focused',
    };
}

const superProps = Buffer.from(JSON.stringify(getSuperProperties())).toString('base64');

class UserbotClient {
    constructor(db, userId, token, prefix, onMessage, onStatus) {
        this.db = db;
        this.userId = userId;
        this.token = token;
        this.prefix = prefix || '!';
        this.onMessage = onMessage;   // callback(messageData)
        this.onStatus = onStatus;     // callback(statusString)
        this.ws = null;
        this.heartbeatInterval = null;
        this.reconnectAttempts = 0;
        this.connected = false;
        this.sessionId = null;
        this.sequence = 0;
    }

    // Create a REST client for this user token
    rest() {
        return axios.create({
            baseURL: DISCORD_API,
            headers: {
                Authorization: this.token,
                Accept: '*/*',
                'Accept-Language': 'en-US',
                'Content-Type': 'application/json',
                'User-Agent': USER_AGENT,
                'X-Super-Properties': superProps,
                'X-Discord-Locale': 'en-US',
                'X-Discord-Timezone': 'Asia/Saigon',
                'X-Debug-Options': 'bugReporterEnabled',
            }
        });
    }

    // Get gateway URL with intents
    async getGateway() {
        const client = this.rest();
        try {
            const res = await client.get('/gateway/bot');
            return res.data;
        } catch (err) {
            // Fallback: use default gateway URL
            this.onStatus('gateway fetch failed, using default URL');
            return {
                url: 'wss://gateway.discord.gg',
                session_start_limit: { total: 1, remaining: 1 },
                shred: 100
            };
        }
    }

    // Connect to the Discord gateway
    async connect() {
        try {
            const gw = await this.getGateway();
            const wsUrl = gw.url;

            this.ws = new WebSocket(`${wsUrl}/?v=10&encoding=json&client_build_number=${CLIENT_BUILD_NUMBER}`);

            this.ws.on('open', () => {
                this.connected = true;
                this.reconnectAttempts = 0;
                this.onStatus('connected');

                // Identify
                this.ws.send(JSON.stringify({
                    op: 2,
                    d: {
                        token: this.token,
                        properties: {
                            os: 'Windows',
                            browser: 'Discord Client',
                            os_version: '10.0.19045',
                            os_arch: 'x64',
                            app_arch: 'x64',
                            platform: 'desktop',
                            release_channel: 'stable',
                            client_version: '1.0.9215',
                            client_build_number: CLIENT_BUILD_NUMBER,
                            native_build_number: 72186,
                            browser_user_agent: USER_AGENT,
                            browser_version: '37.6.0',
                            system_locale: 'en-US',
                            has_client_mods: false,
                            client_event_source: null
                        },
                        capabilities: 191,
                        large_threshold: 250,
                        intents: 513 | 4 | 2 // guilds, message content, messages
                    }
                }));
            });

            this.ws.on('message', (data) => {
                const msg = JSON.parse(data);
                this.sequence = msg.s || this.sequence;

                if (msg.t === 'READY') {
                    this.sessionId = msg.d.session_id;
                    this.onStatus(`ready (session: ${this.sessionId?.substring(0,8)}...)`);

                    // Store session ID
                    this.db.prepare('UPDATE discord_settings SET gateway_session_id = ? WHERE user_id = ?')
                        .run(this.sessionId, this.userId);

                    // Start heartbeat
                    const heartbeatInterval = msg.d.heartbeat_interval;
                    this.startHeartbeat(Math.floor(heartbeatInterval));
                }

                if (msg.t === 'MESSAGE_CREATE') {
                    // Only process messages from the userbot owner
                    if (msg.d.author?.id === String(this.userId)) {
                        this.handleCommand(msg.d);
                    }
                }

                // Auto-reconnect on session invalidated
                if (msg.t === 'RESUMABLE' || (msg.t === 'SESSION_STARTED' && msg.op === 7)) {
                    this.onStatus('reconnecting...');
                    setTimeout(() => this.connect(), 5000);
                }
            });

            this.ws.on('close', (code, reason) => {
                this.connected = false;
                this.onStatus(`disconnected (${code})`);
                if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);

                // Reconnect with backoff
                const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000);
                this.reconnectAttempts++;
                setTimeout(() => this.connect(), delay);
            });

            this.ws.on('error', (err) => {
                this.onStatus(`error: ${err.message}`);
            });

            // Heartbeat
            this.ws.on('pong', () => {
                this.db.prepare('UPDATE discord_settings SET last_heartbeat = ? WHERE user_id = ?')
                    .run(new Date().toISOString(), this.userId);
            });

        } catch (err) {
            this.onStatus(`connection error: ${err.message}`);
            setTimeout(() => this.connect(), 10000);
        }
    }

    startHeartbeat(intervalMs) {
        if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
        this.heartbeatInterval = setInterval(() => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({ op: 10, d: { client_hello: { properties: {} } } }));
                this.ws.send(JSON.stringify({
                    op: 1,
                    d: Date.now(),
                    s: this.sequence,
                    t: null
                }));
            }
        }, intervalMs);
    }

    // Parse and handle prefix commands
    async handleCommand(message) {
        const content = message.content || '';
        if (!content.startsWith(this.prefix)) return;

        // Split: prefix + command + args
        const args = content.slice(this.prefix.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();
        const fullArgs = args.join(' ');

        this.onMessage({
            type: 'command',
            command,
            args: fullArgs,
            message,
            timestamp: new Date().toISOString()
        });

        try {
            // --- Quest Commands ---
            if (command === 'quest') {
                const sub = args.shift()?.toLowerCase() || '';
                if (sub === 'start') {
                    await this.triggerQuestCompletion();
                } else if (sub === 'status') {
                    await this.sendQuestStatus(message.channel_id);
                }
            }

            // --- Streaming Commands ---
            else if (command === 'stream') {
                if (!fullArgs) {
                    await this.sendRichPresence('idle', null);
                } else {
                    await this.sendRichPresence('streaming', fullArgs);
                }
            }
            else if (command === 'rpc' && args[0]?.toLowerCase() === 'stop') {
                await this.sendRichPresence('clear', null);
            }

            // --- Prefix Management ---
            else if (command === 'setprefix') {
                const newPrefix = fullArgs;
                if (newPrefix && newPrefix.length === 1) {
                    this.prefix = newPrefix;
                    this.db.prepare('UPDATE users SET prefix = ? WHERE id = ?')
                        .run(newPrefix, this.userId);
                    this.db.prepare('UPDATE discord_settings SET userbot_enabled = 1 WHERE user_id = ?')
                        .run(this.userId);
                    await this.sendDM(message.channel_id, `✅ Prefix set to: \`${newPrefix}\``);
                    this.onStatus(`prefix updated to: ${newPrefix}`);
                } else {
                    await this.sendDM(message.channel_id, `❌ Usage: \`${this.prefix}setprefix <char>\` (single character)`);
                }
            }

            // --- Ping ---
            else if (command === 'ping') {
                const latency = this.ws ? (Date.now() - (this.ws.lastPong || Date.now())) : 0;
                const ws = WebSocket; // dummy reference
                await this.sendDM(message.channel_id, `🏓 Pong! Latency: ${latency}ms`);
            }

        } catch (err) {
            this.onMessage({
                type: 'error',
                command,
                message: err.message,
                timestamp: new Date().toISOString()
            });
            // Try to send error to user
            try {
                await this.sendDM(message.channel_id, `❌ Error executing \`${command}\`: ${err.message}`);
            } catch (e) { /* ignore */ }
        }
    }

    // Send a DM message
    async sendDM(channelId, content, embeds = []) {
        if (!channelId) return; // No channel = just log via onStatus
        try {
            const client = this.rest();
            await client.post('/channels/' + channelId + '/messages', {
                content,
                embeds
            });
        } catch (err) {
            this.onStatus(`send DM failed: ${err.response?.data?.message || err.message}`);
        }
    }

    // Trigger quest completion for all active tokens
    async triggerQuestCompletion() {
        const tokens = this.db.prepare(
            'SELECT id, token, label FROM tokens WHERE user_id = ? AND status = ?'
        ).all(this.userId, 'active');

        if (tokens.length === 0) {
            return { completed: 0, failed: 0, message: 'No active tokens found.' };
        }

        let completed = 0;
        let failed = 0;
        const results = [];

        for (const tokenRow of tokens) {
            try {
                // Inline quest completion logic (server.js is not exported as a module)
                const questRes = await this.fetchQuestForToken(tokenRow.token);
                const activeQuests = this.filterActiveQuests(questRes);

                if (activeQuests.length === 0) {
                    results.push({ token: tokenRow.label, status: 'no-quests' });
                    continue;
                }

                for (const quest of activeQuests) {
                    const result = await this.solveSingleQuest(tokenRow.token, quest);
                    results.push({ token: tokenRow.label, quest: quest.config?.messages?.quest_name || quest.id, result });
                    if (result.status === 'completed') completed++;
                    else failed++;
                }
            } catch (err) {
                const status = err.response?.status;
                if (status === 401) {
                    this.db.prepare('UPDATE tokens SET status = ? WHERE id = ?').run('invalid', tokenRow.id);
                    results.push({ token: tokenRow.label, status: 'invalid-token' });
                } else {
                    failed++;
                    results.push({ token: tokenRow.label, status: 'error', error: err.message });
                }
            }
        }

        return { completed, failed, results };
    }

    // Fetch active quests for a token
    async fetchQuestForToken(token) {
        const client = axios.create({
            baseURL: DISCORD_API,
            headers: { Authorization: token, 'User-Agent': USER_AGENT, 'X-Super-Properties': superProps }
        });
        const res = await client.get('/quests/@me');
        return res.data.quests || [];
    }

    filterActiveQuests(quests) {
        return quests.filter(q => {
            if (q.id === '1412491570820812933') return false;
            const cfg = q.config || {};
            if (cfg.expires_at && new Date() > new Date(cfg.expires_at)) return false;
            if (q.user_status?.completed_at) return false;
            return true;
        });
    }

    async solveSingleQuest(token, quest) {
        const client = axios.create({
            baseURL: DISCORD_API,
            headers: { Authorization: token, 'User-Agent': USER_AGENT, 'X-Super-Properties': superProps }
        });
        const qId = quest.id;
        const taskConfig = quest.config?.task_config_v2 || quest.config?.task_config || {};
        const tasks = taskConfig.tasks || {};
        const taskName = ['WATCH_VIDEO', 'WATCH_VIDEO_ON_MOBILE', 'PLAY_ON_DESKTOP', 'PLAY_ACTIVITY'].find(t => t in tasks) || Object.keys(tasks)[0];

        if (!taskName) return { status: 'failed', error: 'Unknown quest type' };
        const secondsNeeded = tasks[taskName]?.target || 900;

        try {
            await client.post(`/quests/${qId}/enroll`, { location: 11 });
        } catch (e) {
            if (e.response?.data?.message !== 'Quest already enrolled.') {
                return { status: 'failed', error: e.response?.data?.message || e.message };
            }
        }

        if (taskName.startsWith('WATCH')) {
            let progress = 0;
            while (progress < secondsNeeded) {
                try {
                    const data = await client.post(`/quests/${qId}/video-progress`, { timestamp: progress });
                    progress += 15;
                    if (data.completed_at) return { status: 'completed', questId: qId };
                } catch (e) {
                    return { status: 'failed', error: e.response?.data?.message || e.message };
                }
                await new Promise(r => setTimeout(r, 1000));
            }
            return { status: 'completed', questId: qId };
        }

        if (taskName === 'PLAY_ON_DESKTOP') {
            const appId = quest.config?.application?.id;
            let progress = 0;
            while (progress < secondsNeeded) {
                try {
                    const data = await client.post(`/quests/${qId}/heartbeat`, { application_id: appId, terminal: false });
                    progress = data?.progress?.PLAY_ON_DESKTOP?.value || progress + 30;
                } catch (e) {
                    return { status: 'failed', error: e.response?.data?.message || e.message };
                }
                await new Promise(r => setTimeout(r, 1000));
            }
            return { status: 'completed', questId: qId };
        }

        return { status: 'failed', error: `Unsupported: ${taskName}` };
    }

    // Fetch current quest status (for <prefix>quest status)
    async sendQuestStatus(channelId) {
        const tokens = this.db.prepare(
            'SELECT id, label FROM tokens WHERE user_id = ? AND status = ?'
        ).all(this.userId, 'active');

        if (tokens.length === 0) {
            await this.sendDM(channelId, 'ℹ️ No active tokens.');
            return;
        }

        let statusMsg = '📊 **Quest Status**\n\n';
        for (const tokenRow of tokens) {
            try {
                const client = this.rest();
                const res = await client.get('/quests/@me');
                const quests = res.data.quests || [];
                const active = this.filterActiveQuests(quests);
                statusMsg += `**${tokenRow.label || 'Token ' + tokenRow.id}**: ${active.length} active quest(s)\n`;
                active.forEach(q => {
                    const name = q.config?.messages?.quest_name || 'Unknown';
                    const progress = q.user_status?.progress || {};
                    const keys = Object.keys(progress);
                    const p = keys.length > 0 ? progress[keys[0]] : {};
                    statusMsg += `   • ${name} — ${p.value || 0}/${p.event_name || '?'}\n`;
                });
            } catch (err) {
                statusMsg += `**${tokenRow.label || tokenRow.id}**: ❌ ${err.response?.data?.message || err.message}\n`;
            }
        }

        await this.sendDM(channelId, statusMsg);
    }

    // Set Rich Presence / Streaming status via REST API
    async sendRichPresence(mode, title) {
        const client = this.rest();

        if (mode === 'clear') {
            // Clear custom status: remove activities
            try {
                const settings = await client.get('/users/@me/settings').then(r => r.data);
                await client.patch('/users/@me/settings', {
                    custom_status: null,
                    activities: []
                });
                this.db.prepare('UPDATE discord_settings SET streaming_status = ?, streaming_title = ? WHERE user_id = ?')
                    .run(null, null, this.userId);
                this.onStatus('Custom status cleared');
            } catch (err) {
                this.onStatus('Clear status error: ' + (err.response?.data?.message || err.message));
            }
        } else if (mode === 'streaming') {
            // Set streaming activity via custom status + activities
            try {
                await client.patch('/users/@me/settings', {
                    custom_status: {
                        state: title,
                        text: title,
                        emoji_id: null
                    },
                    activities: [{
                        name: title,
                        type: 1, // STREAMING
                        url: title
                    }]
                });
                this.db.prepare('UPDATE discord_settings SET streaming_status = ?, streaming_title = ? WHERE user_id = ?')
                    .run('streaming', title, this.userId);
                this.onStatus('Streaming set: ' + title);
            } catch (err) {
                this.onStatus('Stream error: ' + (err.response?.data?.message || err.message));
            }
        }
    }

    // Disconnect cleanly
    disconnect() {
        if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
        if (this.ws) this.ws.close();
        this.connected = false;
        this.onStatus('disconnected');
    }
}

module.exports = UserbotClient;

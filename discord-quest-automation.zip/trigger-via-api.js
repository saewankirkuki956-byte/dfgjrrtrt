const axios = require('axios');
const jwt = require('jsonwebtoken');
const db = require('better-sqlite3')('./tokens.db');
const JWT_SECRET = 'discord-quest-secret-key-change-in-production';

const user = db.prepare('SELECT * FROM users WHERE username = ?').get('hama');
const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
const headers = { Authorization: `Bearer ${token}` };

(async () => {
  try {
    const r = await axios.get('http://localhost:3000/api/tokens/list', { headers });
    console.log('Tokens:', JSON.stringify(r.data, null, 2));
    
    console.log('\nTriggering quest execution...');
    const c = await axios.post('http://localhost:3000/api/tokens/complete', { tokenId: 4 }, { timeout: 300000, headers });
    console.log('Result:', JSON.stringify(c.data, null, 2));
    
    const l = await axios.get('http://localhost:3000/api/logs', { headers });
    console.log('\nRecent logs:');
    l.data.logs.slice(0, 20).forEach(e => console.log('  [' + e.status + '] ' + e.message + ' (' + new Date(e.timestamp).toISOString() + ')'));
  } catch(e) {
    console.error('Error:', e.response?.status, JSON.stringify(e.response?.data || e.message));
  }
})();

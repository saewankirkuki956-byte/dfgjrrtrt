#!/bin/bash
# start.sh — Start the quest automation server in background
cd /c/Users/hama/discord-quest-automation
exec node server.js < /dev/null

@echo off
cd /d C:\Users\hama\discord-quest-automation
start "discord-quest-server" cmd /c "node server.js"
timeout /t 3 /nobreak >nul
curl -s http://localhost:3000/api/scheduler/status

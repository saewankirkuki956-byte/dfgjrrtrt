const db = require('better-sqlite3')('./tokens.db');

// Delete logs referencing old tokens first (FK constraint)
db.prepare('DELETE FROM quest_logs WHERE token_id IN (1, 2, 3)').run();
console.log('Deleted logs for old tokens');

// Now delete old tokens
db.prepare('DELETE FROM tokens WHERE id IN (1, 2, 3)').run();
console.log('Removed old/invalid tokens');

// Verify
const tokens = db.prepare('SELECT id, user_id, token, label, status FROM tokens').all();
console.log('Remaining tokens:', JSON.stringify(tokens, null, 2));

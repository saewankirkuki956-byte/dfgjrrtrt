@echo off
cd /d C:\Users\hama\discord-quest-automation
node server.js
